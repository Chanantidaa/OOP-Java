package ChanantidaProject;

public class Snack extends Product{
	public String flavour;
	public void showDetail() {
		System.out.print("Product Name:"+name);
		System.out.print("Price:"+name);
		System.out.print("Flavour:"+flavour);
}
}
