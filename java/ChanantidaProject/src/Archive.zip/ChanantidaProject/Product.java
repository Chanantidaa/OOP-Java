package ChanantidaProject;

public class Product {
	public String name = "Sprite";
	public int price = 40;
	
	public void onSale() {
		System.out.println("Thank you");
	}

}
