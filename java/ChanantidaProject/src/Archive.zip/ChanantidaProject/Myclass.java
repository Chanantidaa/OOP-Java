package ChanantidaProject;

public class Myclass {
	public static void main (String args[]) {
//		STUDENT s1 = new STUDENT();
//		STUDENT s2 = new STUDENT();
//		STUDENT s3 = new STUDENT();
//		
//		s1.setID("64070260");
//		s1.setName("Chanantida");
//		s1.setGPA(3.25);
//		s1.showDetail();
//		
//		s2.setID("64070277");
//		s2.setName("Pancheewa");
//		s2.setGPA(3.25);
//		s2.showDetail();
//		
//		s3.setID("64070260");
//		s3.setName("Chanantida");
//		s3.setGPA(3.25);
//		s3.showDetail();		
	}
}