package Classcar;

public class Car {
	public String id = "999";
	public void start() {
		System.out.println(id);
	}

}
