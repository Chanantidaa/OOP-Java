package Classcar;

public class Driver {
	public String name;
	public void drive() {
		System.out.println(name);
	}

}
