package Classcar;

public class Fossil extends Car{

}
