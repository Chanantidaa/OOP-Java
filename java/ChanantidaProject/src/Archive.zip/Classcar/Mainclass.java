package Classcar;

import java.util.Scanner;

public class Mainclass {
	public static void main (String args[]) {
//		Car c1 = new Car();
//		EV c2 = new EV();
//		Fossil c3 = new Fossil();
//		Driver d1 = new Driver();
//		
//		//c1.start();
//		//d1.drive();
//		
//		c2.start();
//		c2.start("Test",5);
//		int z = c2.start(1,2);
//		System.out.println("z = "+z);
		
		Scanner reader = new Scanner(System.in);
		String x = reader.next();
		System.out.println(x);
		
	}

}
