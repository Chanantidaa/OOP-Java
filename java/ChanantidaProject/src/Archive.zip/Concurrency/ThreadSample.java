package Concurrency;

public class ThreadSample {

}
