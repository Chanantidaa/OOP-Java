package ProductPayment;

public class Drink extends Product {
		private String type = "Cola";
		{
		name = "Pepsi";
		price = 8;
		}
}

/*		public void showDetail() {
			System.out.println("Product Name: "+name);
			System.out.println("Price: "+price+"Baht");
			System.out.println("Type: "+type);
		}
}*/
