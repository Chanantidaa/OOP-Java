package ProductPayment;

public class Snack extends Product{
		private String flavour = "BBQ";
		{
		name = "Lay";
		price = 10;
		}
public void showDetail() {
	System.out.println("Product Name: "+name);
	System.out.println("Price: "+price);
	System.out.println("Flavour: "+flavour);
}
}
		
		/*		public void showDetail() {
			System.out.println("Product Name: "+name);
			System.out.println("Price: "+price+"Baht");
			System.out.println("Type: "+flavour);
			
		}
}*/
