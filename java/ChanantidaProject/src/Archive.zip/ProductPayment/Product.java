package ProductPayment;

public class Product {
		protected String name;
		protected int price;
} 
		
/*		public void onSale() {
			System.out.println("Thank you");
		}

	}*/
